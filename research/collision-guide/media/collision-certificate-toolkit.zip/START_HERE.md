# Reproduce the finite-polynomial certificate

Requires Python 3.11 or later, using only the standard library. Run from this extracted folder:

```powershell
python -B research/collision-guide/use_certificate.py --roots=-3,-1,1,3 --duration=17/32 --output example.json
```

The interval status should be `certified`; the exact point check should report four distinct real roots and gcd degree zero. Use duration `3/5` to see an uncertified interval endpoint that nevertheless still has four simple real roots. `2/3` is an exact double-root collision in this example, and `7/10` has no real roots.

Read research/collision-guide/guide.md for the assumptions, derivation, discovery history, applications and RH connection. The finite-degree theorem does not establish an infinite-system theorem or a new prime algorithm; novelty has not been established. JSON evidence records the specific cases and source hashes reviewed, rather than certifying every possible input.

The full public project and historical trace sources are at https://github.com/UserLevelUp/Graphics on branch graph/riemann-continuation. Historical source paths in receipts refer to that repository. This compact kit includes the checker and proofs needed for the example, not every historical record or media file.
